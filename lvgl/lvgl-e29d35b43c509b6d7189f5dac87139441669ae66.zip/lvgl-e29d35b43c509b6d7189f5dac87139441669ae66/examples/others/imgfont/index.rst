Use emojis in a text.
---------------------

.. lv_example:: others/imgfont/lv_example_imgfont_1
  :language: c

